#!/usr/bin/perl
# Automatically Generated, do not edit anything but the path above!

$host = `host @ARGV 2>/dev/null`;
if ($host eq "") {
        print "Host not found, try again.\n";
} else {
        foreach $line ($host) {
                print "$line";
        }
}

